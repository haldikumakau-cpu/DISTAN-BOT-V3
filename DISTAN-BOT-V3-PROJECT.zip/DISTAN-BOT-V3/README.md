# DISTAN BOT V3 — starter project
Tema aplikasi: hitam-hijau. Berisi dashboard Android sederhana dan backend Node.js awal.

PENTING:
- APK ini adalah dashboard pendamping, bukan aplikasi WhatsApp resmi.
- Backend perlu di-deploy ke host Node.js online dengan penyimpanan persisten agar sesi QR tersimpan.
- Baileys adalah integrasi tidak resmi dan dapat menimbulkan risiko pembatasan akun WhatsApp. Patuhi ketentuan WhatsApp dan kirim pesan hanya kepada penerima yang menyetujuinya.
- Ini masih starter: pairing QR di aplikasi, broadcast, dan kontrol jarak jauh belum selesai. Belum siap dipakai sebagai bot produksi.

Build APK: Android Gradle project; output app/build/outputs/apk/debug/app-debug.apk.
Backend: masuk folder backend, jalankan npm install lalu npm start pada host Node.js dengan storage persisten. Jangan publikasikan folder auth_info atau kredensial sesi.
